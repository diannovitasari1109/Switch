/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Switch_Dian;

import java.util.Scanner;

/**
 *
 * @author DNS
 */
public class Switch_Dian {
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Masukan kode hari 1-7");
        Scanner ha = new Scanner(System.in);
       
        int nomor;
        
        nomor = ha.nextInt();
        
        switch (nomor){
            case 1:
                System.out.println("Senin");
                break;
            case 2:
                System.out.println("Selasa");
                break;
            case 3:
                System.out.println("Rabu");
                break;
            case 4:
                System.out.println("Kamis");
                break;
            case 5:
                System.out.println("Jum'at");
                break;
            case 6:
                System.out.println("Sabtu");
                break;
            case 7:
                System.out.println("Minggu");
                break;
            default:
                System.out.println("Format yang anda masukan salah");
                
            
        }
        
        
    }
    
}
